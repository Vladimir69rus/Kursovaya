﻿using System;
using System.Windows.Forms;

namespace Kursovaya
{
    public partial class Form2 : Form
    {
        public string txtPointsQuantity;
        public string txtPointsSize;
        public string txtLineWidth;
        public Form2(Form1 f)
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = this.Owner as Form1;
            txtPointsQuantity = textBox1.Text;
            txtPointsSize = textBox2.Text;
            txtLineWidth = textBox3.Text;
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
