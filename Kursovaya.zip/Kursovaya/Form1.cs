﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Patsev.Integrals;
using ZedGraph;

namespace Kursovaya

{
    public partial class Form1 : Form
    {
        public int PointsQuantity { get; set; }
        public int PointsSize { get; set; }
        public float LineWidth { get; set; }
        double x1 { get; set; }
        double x2 { get; set; }
        int n { get; set; }
        string strMethodRectangles, strTrapezoids, strSimpsons; //Строки для хранения результатов
        string strCalcStatus; //информационная строка

        public Form1()
        {
            InitializeComponent();
        }

        private void DisambleButtons()
        {
            button1.Enabled = false;
            файлToolStripMenuItem.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            strMethodRectangles = "";
            strTrapezoids = "";
            strSimpsons = "";
            strCalcStatus = "Вычисление...\nНажмите 'x'\n для отмены.";
            DrawGraph();
        }

        private void EnableButtons(object sender, RunWorkerCompletedEventArgs e)
        {
            button1.Enabled = true;
            файлToolStripMenuItem.Enabled = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            strCalcStatus = "";
            DrawGraph();
        }

        private void Integration(object sender, DoWorkEventArgs e)
        {
            Integral myIntegral;
            Integral.Killed = false;
            myIntegral = new Rectangles(x1, x2, n);
            strMethodRectangles = myIntegral.ToString();
            myIntegral = new Trapezoids(x1, x2, n);
            strTrapezoids = myIntegral.ToString();
            myIntegral = new Simpsons(x1, x2, n);
            strSimpsons = myIntegral.ToString();
        }//интегрирование

        public void DrawGraph() //вывод графика функции
        {
            // Получим панель для рисования
            GraphPane pane = zedGraph.GraphPane;
            // Очистим список текстов и кривых на тот случай, если до этого сигналы уже были нарисованы
            pane.CurveList.Clear();
            pane.GraphObjList.Clear();
            // Печать заголовка
            TextObj headline = new TextObj("Значение интеграла / Погрешность", 0.27F, 0.04F);
            headline.FontSpec.FontColor = Color.DarkBlue;
            headline.FontSpec.IsBold = true;
            headline.FontSpec.Size = 8;
            headline.FontSpec.IsAntiAlias = true;
            // Disable the border and background fill options for the text
            headline.FontSpec.Border.IsVisible = false;
            headline.FontSpec.Fill.IsVisible = false;
            headline.FontSpec.IsUnderline = true;
            // Align the text such the the Left-Bottom corner is at the specified coordinates
            // use AxisFraction coordinates so the text is placed relative to the ChartRect
            headline.Location.CoordinateFrame = CoordType.ChartFraction;
            headline.Location.AlignH = AlignH.Left;
            headline.Location.AlignV = AlignV.Bottom;
            pane.GraphObjList.Add(headline);
            //Печать подписей к результатам
            string textline = "Метод прямоугольников: \nМетод трапеций: \nМетод парабол:";
            TextObj textresults = new TextObj(textline, 0.04F, 0.15F);
            textresults.Location.CoordinateFrame = CoordType.ChartFraction;
            textresults.FontSpec.Border.IsVisible = false;
            textresults.FontSpec.Fill.IsVisible = false;
            textresults.FontSpec.IsAntiAlias = true;
            textresults.FontSpec.Size = 8;
            textresults.Location.AlignH = AlignH.Left;
            textresults.Location.AlignV = AlignV.Bottom;
            textresults.FontSpec.StringAlignment = StringAlignment.Near;
            pane.GraphObjList.Add(textresults);
            //Печать результатов
            string strresults = strMethodRectangles + "\n" + strTrapezoids + "\n" + strSimpsons;
            TextObj results = new TextObj(strresults, 0.27F, 0.15F);
            results.Location.CoordinateFrame = CoordType.ChartFraction;
            results.FontSpec.FontColor = Color.DarkGreen;
            results.FontSpec.Border.IsVisible = false;
            results.FontSpec.Fill.IsVisible = false;
            results.FontSpec.IsAntiAlias = true;
            results.FontSpec.Size = 8;
            results.Location.AlignH = AlignH.Left;
            results.Location.AlignV = AlignV.Bottom;
            results.FontSpec.StringAlignment = StringAlignment.Near;
            pane.GraphObjList.Add(results);
            //Печать надписи "Вычисление..."
            TextObj txtCalc = new TextObj(strCalcStatus, 0.8F, 0.05F);
            // use AxisFraction coordinates so the text is placed relative to the ChartRect
            txtCalc.Location.CoordinateFrame = CoordType.ChartFraction;
            // rotate the text 15 degrees
            txtCalc.FontSpec.Angle = -45.0F;
            // Text will be red, bold, and 16 point
            txtCalc.FontSpec.FontColor = Color.Red;
            txtCalc.FontSpec.IsBold = true;
            txtCalc.FontSpec.Size = 16;
            // Disable the border and background fill options for the text
            txtCalc.FontSpec.Border.IsVisible = false;
            txtCalc.FontSpec.Fill.IsVisible = false;
            // Align the text such the the Left-Bottom corner is at the specified coordinates
            txtCalc.Location.AlignH = AlignH.Left;
            txtCalc.Location.AlignV = AlignV.Bottom;
            pane.GraphObjList.Add(txtCalc);

            //Вывод графика:
            // Создадим список точек
            PointPairList list = new PointPairList();
            PointPairList plist = new PointPairList();
            double xmin = x1;
            double xmax = x2;
            // Заполняем список точек
            if (textBox1.Text != null && Convert.ToDouble(textBox1.Text) != 0 && textBox2.Text != null && Convert.ToDouble(textBox2.Text) != 0 && textBox3.Text != null && Convert.ToInt32(textBox3.Text) != 0)
            {
                plist.Add(xmin, Integral.F(xmin));
                double xp = Math.Max(Math.Abs(xmin), Math.Abs(xmax));
                double dx = 2 * xp * 1.2 / this.PointsQuantity;
                for (double x = -xp * 1.2; x <= xp * 1.2; x += dx)
                {
                    // добавим в список точку
                    list.Add(x, Integral.F(x));
                    if (x >= xmin && x <= xmax)
                        plist.Add(x, Integral.F(x));
                }
                plist.Add(xmax, Integral.F(xmax));
                // Set the titles and axis labels
                pane.Title.Text = "Интегрируемая функция f(x) = 1/Sqrt(1 + x^2)";
                pane.XAxis.Title.Text = "X";
                pane.YAxis.Title.Text = "Y";
                // Hide the legend
                pane.Legend.IsVisible = false;
                // Add a curve
                LineItem curve = pane.AddCurve("label", list, Color.Red, SymbolType.Circle);
                curve.Line.IsSmooth = true;
                curve.Line.Width = this.LineWidth;
                curve.Symbol.Fill = new Fill(Color.White);
                curve.Symbol.Size = this.PointsSize;
                // Fill the area under the curves
                LineItem pcurve = pane.AddCurve("", plist, Color.Blue, SymbolType.None);
                pcurve.Line.IsSmooth = true;
                pcurve.Line.Fill = new Fill(Color.White, Color.Blue, 95.0F);
                // Fill the axis background with a gradient
                pane.Chart.Fill = new Fill(Color.White, Color.SteelBlue, 90.0F);
                // Включим отображение сетки
                pane.XAxis.MajorGrid.IsVisible = true;
                pane.YAxis.MajorGrid.IsVisible = true;
                /* Вызываем метод AxisChange (), чтобы обновить данные об осях.
                В противном случае на рисунке будет показана только часть графика, которая умещается в интервалы по осям, установленные по умолчанию*/
                zedGraph.AxisChange();
                // Обновляем график
                zedGraph.Invalidate();
            }
            else
            {
                plist.Add(xmin, Integral.F(xmin));
                double xp = Math.Max(Math.Abs(xmin), Math.Abs(xmax));
                double dx = 2 * xp * 1.2 / 0;
                for (double x = -xp * 1.2; x <= xp * 1.2; x += dx)
                {
                    // добавим в список точку
                    list.Add(x, Integral.F(x));
                    if (x >= xmin && x <= xmax)
                        plist.Add(x, Integral.F(x));
                }
                plist.Add(xmax, Integral.F(xmax));
                // Set the titles and axis labels
                pane.Title.Text = "Интегрируемая функция f(x) = 1/Sqrt(1 + x^2)";
                pane.XAxis.Title.Text = "X";
                pane.YAxis.Title.Text = "Y";
                // Hide the legend
                pane.Legend.IsVisible = false;
                // Add a curve
                LineItem curve = pane.AddCurve("label", list, Color.Red, SymbolType.Circle);
                curve.Line.IsSmooth = true;
                curve.Line.Width = 0;
                curve.Symbol.Fill = new Fill(Color.White);
                curve.Symbol.Size = 0;
                // Fill the area under the curves
                LineItem pcurve = pane.AddCurve("", plist, Color.Blue, SymbolType.None);
                pcurve.Line.IsSmooth = true;
                pcurve.Line.Fill = new Fill(Color.White, Color.Blue, 95.0F);
                // Fill the axis background with a gradient
                pane.Chart.Fill = new Fill(Color.White, Color.SteelBlue, 90.0F);
                // Включим отображение сетки
                pane.XAxis.MajorGrid.IsVisible = true;
                pane.YAxis.MajorGrid.IsVisible = true;
                /* Вызываем метод AxisChange (), чтобы обновить данные об осях.
                В противном случае на рисунке будет показана только часть графика, которая умещается в интервалы по осям, установленные по умолчанию*/
                zedGraph.AxisChange();
                // Обновляем график
                zedGraph.Invalidate();
            }
        }//прорисовка графика

        private void button1_Click(object sender, EventArgs e)
        {
            //проверка корректности вводимых значений
            try

            {
                try
                {
                    x1 = Convert.ToDouble(textBox1.Text);
                }
                catch
                {
                    textBox1.Focus();
                    textBox1.SelectAll();
                    throw new Exception("Ошибка при вводе x1");
                }
                try
                {
                    x2 = Convert.ToDouble(textBox2.Text);
                }
                catch
                {
                    textBox2.Focus();
                    textBox2.SelectAll();
                    throw new Exception("Ошибка при вводе x2");
                }
                try
                {
                    n = Convert.ToInt32(textBox3.Text);
                }
                catch
                {
                    textBox3.Focus();
                    textBox3.SelectAll();
                    throw new Exception("Ошибка при вводе n");
                }
                DisambleButtons();
                BackgroundWorker bw = new BackgroundWorker();
                bw.WorkerSupportsCancellation = true;
                bw.DoWork += Integration;
                bw.RunWorkerCompleted += EnableButtons;
                bw.RunWorkerAsync(null);
            }
            catch (Exception myexcepton)
            {
                MessageBox.Show(myexcepton.Message, "Ошибка ввода данных.");
            }
        }

        private void zedGraph_DoubleClick(object sender, EventArgs e)
        {
            zedGraph.GraphPane.CurveList.Clear();
            zedGraph.GraphPane.GraphObjList.Clear();
            zedGraph.Invalidate();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            x1 = Convert.ToDouble(textBox1.Text);
            x2 = Convert.ToDouble(textBox2.Text);
            n = Convert.ToInt32(textBox3.Text);
            DrawGraph();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 120 || e.KeyChar == 1095) //отмена вычислений при нажатии 'x'
            {
                Integral.Killed = true;
                strMethodRectangles = "";
                strTrapezoids = "";
                strSimpsons = "";
            }
        }

        //Настройки
        public void настройкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 SettingsFrm = new Form2(this);
            SettingsFrm.Owner = this;
            SettingsFrm.txtPointsQuantity = this.PointsQuantity.ToString();
            SettingsFrm.txtPointsSize = this.PointsSize.ToString();
            SettingsFrm.txtLineWidth = this.LineWidth.ToString();
            SettingsFrm.ShowDialog();
            if (SettingsFrm.button1.Enabled == true)
            {
                try
                {
                    try
                    {
                        this.PointsQuantity = Convert.ToInt32(SettingsFrm.txtPointsQuantity);
                    }
                    catch
                    {
                        throw new Exception("Ошибка при вводе количества точек на графике");
                    }
                    try
                    {
                        this.PointsSize = Convert.ToInt32(SettingsFrm.txtPointsSize);
                    }
                    catch
                    {
                        throw new Exception("Ошибка при вводе размера точек");
                    }
                    try
                    {
                        this.LineWidth = Convert.ToSingle(SettingsFrm.txtLineWidth);
                    }
                    catch
                    {
                        throw new Exception("Ошибка при вводе толщины линии");
                    }
                }
                catch (Exception myexcepton)
                {
                    MessageBox.Show(myexcepton.Message + "\nОшибочные изменения не будут произведены."
                    , "Ошибка ввода данных.");
                }
            }
        }

        //О программе
        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
